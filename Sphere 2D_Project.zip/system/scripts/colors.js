Black   = CreateColor(0,   0,   0,   255);
White   = CreateColor(255, 255, 255, 255);
Red     = CreateColor(255, 0,   0,   255);
Green   = CreateColor(0,   255, 0,   255);
Blue    = CreateColor(0,   0,   255, 255);
Cyan    = CreateColor(0,   255, 255, 255);
Magenta = CreateColor(255, 0,   255, 255);
Yellow  = CreateColor(255, 255, 0,   255);
