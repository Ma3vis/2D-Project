Startup System

By tunginobi


<cursor keys> navigate the menus.
<home> and <end> go to the top and bottom of the games list.
<page up> and <page down> go up and down a page-worth of games.

<enter> is the confirm key (and sometimes <space> too).
<esc> is the return/cancel key, and options menu key.

Type <alphanumeric characters> to search.
<backspace> will delete characters from search term.
Search term is searched in both the title and author.
Search is case-insensitive.

This is *NOT* a proud example of my usual coding standards. :(


Late entry for the startup game compo over in the
SphereDev.net forums. Started late, ended later. Funny story.


If you want to use this as your Sphere engine's startup game,
substitute the "startup" directory in the base installation
directory, and put this there in its place.
